from django.apps import AppConfig


class FlexConfig(AppConfig):
    name = 'flex'
