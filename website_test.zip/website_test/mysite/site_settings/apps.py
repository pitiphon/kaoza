from django.apps import AppConfig


class SiteSettingsConfig(AppConfig):
    name = 'site_settings'
