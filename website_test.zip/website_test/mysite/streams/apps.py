from django.apps import AppConfig


class StreamsConfig(AppConfig):
    name = 'streams'
